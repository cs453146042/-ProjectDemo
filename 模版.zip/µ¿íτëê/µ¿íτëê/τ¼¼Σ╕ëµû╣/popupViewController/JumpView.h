//
//  JumpView.h
//  LewPopupViewController
//
//  Created by 程帅 on 16/1/22.
//  Copyright © 2016年 pljhonglu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JumpView : UIView


@property (nonatomic, weak) UIViewController *JumpVC;


@property (nonatomic,copy) void(^BtnNameBlock)(NSString *);

@end
