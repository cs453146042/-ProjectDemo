//
//  JumpView.m
//  LewPopupViewController
//
//  Created by 程帅 on 16/1/22.
//  Copyright © 2016年 pljhonglu. All rights reserved.
//

#import "JumpView.h"
#import "UIViewController+LewPopupViewController.h"
#import "LewPopupViewAnimationFade.h"
#import "LewPopupViewAnimationSlide.h"
#import "LewPopupViewAnimationSpring.h"
#import "LewPopupViewAnimationDrop.h"
#define  KScreenWidth   [UIScreen mainScreen].bounds.size.width

#define  KScreenHeight  [UIScreen mainScreen].bounds.size.height
@implementation JumpView
-(id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.backgroundColor = [UIColor blueColor];
        self.frame = CGRectMake(KScreenWidth/3, KScreenHeight/3, KScreenWidth/3, KScreenHeight/3);
        
    }
     [self addButton];
    return self;
   
}
-(void)addButton
{
    for (int i = 0; i<3; i++) {
        UIButton *btn = [[UIButton alloc] init];
//        btn.backgroundColor = [UIColor yellowColor];
        btn.titleLabel.font = [UIFont systemFontOfSize:13];
        btn.titleLabel.textAlignment = NSTextAlignmentLeft;
        [btn setTitle:@"测试btn" forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        btn.frame = CGRectMake(0, 35*i,100,30);
        [self addSubview:btn];
        [btn addTarget:self action:@selector(click_Btn:) forControlEvents:UIControlEventTouchUpInside];
    }
    [_JumpVC lew_dismissPopupView];
}
-(void)click_Btn:(UIButton *)sender
{
    NSLog(@"sender.titleLabel.text:%@",sender.titleLabel.text);
     _BtnNameBlock([NSString stringWithFormat:@"%@",sender.titleLabel.text]);
    
     [_JumpVC lew_dismissPopupViewWithanimation:[LewPopupViewAnimationSpring new]];
   
}
@end
