//
//  SYModel.m
//  模版
//
//  Created by 程帅 on 16/3/9.
//  Copyright © 2016年 程帅. All rights reserved.
//

#import "SYModel.h"

@implementation SYModel

@end

@implementation data

@end


@implementation Msgdata

+ (NSDictionary *)objectClassInArray{
    return @{@"docsList" : [Docslist class]};
}

@end


@implementation Docslist

@end


