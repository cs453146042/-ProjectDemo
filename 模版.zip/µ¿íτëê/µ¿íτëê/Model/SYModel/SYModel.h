//
//  SYModel.h
//  模版
//
//  Created by 程帅 on 16/3/9.
//  Copyright © 2016年 程帅. All rights reserved.
//

#import <Foundation/Foundation.h>


@class data,Msgdata,Docslist;
@interface SYModel : NSObject

@property (nonatomic, copy) NSString *status;

@property (nonatomic, copy) NSString *info;

@property (nonatomic, strong) data *data;

@end

@interface data : NSObject

@property (nonatomic, copy) NSString *status;

@property (nonatomic, copy) NSString *info;

@property (nonatomic, strong) Msgdata *msgData;

@end

@interface Msgdata : NSObject

@property (nonatomic, strong) NSArray<Docslist *> *docsList;

@end

@interface Docslist : NSObject

@property (nonatomic, copy) NSString *content;

@property (nonatomic, copy) NSString *qname;

@property (nonatomic, copy) NSString *id;

@property (nonatomic, copy) NSString *image;

@property (nonatomic, copy) NSString *create_time;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *desc;

@end

