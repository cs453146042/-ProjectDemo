//
//  DashedView.m
//  Quartz2D绘图
//
//  Created by apple on 15/7/16.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "DashedView.h"

@implementation DashedView

-(instancetype)initWithFrame:(CGRect)frame AndColor:(UIColor *)color{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        self.dashedColor = color;
    }
    return self;
}
- (void)drawRect:(CGRect)rect{
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextSetStrokeColorWithColor(ctx, _dashedColor.CGColor);
    
    CGFloat lengths[] = {5,5};
    CGContextMoveToPoint(ctx, 0, 0);
    CGContextSetLineDash(ctx, 0, lengths, 2);
    CGContextAddLineToPoint(ctx, self.frame.size.width, 1);
    CGContextSetLineWidth(ctx, 1);
    
    CGContextStrokePath(ctx);
    
    
    
}

@end
