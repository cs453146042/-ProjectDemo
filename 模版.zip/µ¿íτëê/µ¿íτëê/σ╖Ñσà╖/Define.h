//
//  Define.h
//  模版
//
//  Created by 程帅 on 15/12/31.
//  Copyright © 2015年 程帅. All rights reserved.
//

#ifndef Define_h
#define Define_h

/*  AppDelegate
 */
#define SHARED_APP_DELEGATE             (AppDelegate *)[UIApplication sharedApplication].delegate

/*
 
 key
 
 */

/*  UIColor
 */
#define UIColorFromRGB(rgbValue)	    UIColorFromRGBA(rgbValue,1.0)

#define UIColorFromRGBA(rgbValue,a)	    [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:a]


/*  DocumentPath
 */
#define DocumentPath                    [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]


/*  iOS版本
 */
#define IOS7                            ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0 ? YES : NO)
#define IOS7Dot0                        ([[[UIDevice currentDevice] systemVersion] floatValue] == 7.0 ? YES : NO)
#define IOS8                            ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0 ? YES : NO)


/*  屏幕尺寸
 */
#define IPHONE4                         ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 960), [[UIScreen mainScreen] currentMode].size) : NO)
#define IPHONE5                         ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 1136), [[UIScreen mainScreen] currentMode].size) : NO)
#define IPHONE6                         ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(750, 1334), [[UIScreen mainScreen] currentMode].size) : NO)
#define IPHONE6PLUS                         ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1242, 2208), [[UIScreen mainScreen] currentMode].size) : NO)


/*  设备方向
 */
#define Portrait            ([[UIDevice currentDevice] orientation]==UIInterfaceOrientationPortrait ? YES : NO)
#define PortraitUpsideDown  ([[UIDevice currentDevice] orientation]==UIInterfaceOrientationPortraitUpsideDown ? YES : NO)
#define LandscapeLeft       ([[UIDevice currentDevice] orientation]==UIInterfaceOrientationLandscapeLeft ? YES : NO)
#define LandscapeRight      ([[UIDevice currentDevice] orientation]==UIInterfaceOrientationLandscapeRight ? YES : NO)


/*  宽高
 */
#define CONTENT_HEIGHT                  ([UIScreen mainScreen].bounds.size.height - 64)
#define kScreenHeight                   [UIScreen mainScreen].bounds.size.height
#define kScreenWidth                    [UIScreen mainScreen].bounds.size.width

#define kTabBarHeight                   self.tabBarController.tabBar.bounds.size.height

/*  较iPhone4屏宽比例
 */
#define kScreenRate                     ([UIScreen mainScreen].bounds.size.width / 320.0f)
#define kScBibi                         kScreenRate/2

/*  颜色
 CD For Color Define
 
 */

#define colorSYBar                      UIColorFromRGB(0xfcf653)

#define CDBACKGROUND                    UIColorFromRGB(0xF2F2F2)
#define CDCELLCLICKBACKGROUND           UIColorFromRGB(0xF5F5F5)
#define CDLineColor                     UIColorFromRGB(0xdedede)             //线条颜色,画线
#define CDBtnMainColor                  UIColorFromRGB(0xff6600)
#define CDCOLOR_SMOKE                   UIColorFromRGB(0x333333)            //深灰  333333
#define CDCOLOR_SMOKE_66                UIColorFromRGB(0x666666)
#define CDCOLOR_TEXT                    UIColorFromRGB(0x999999)            //浅灰
#define CDCOLOR_LINE                    UIColorFromRGB(0xdddddd)            //线条颜色
#define CDCOLOR_GREEN                   UIColorFromRGB(0x8ACF1C)            // 主色调 绿色
#define CDBACKGROUND_COLOR              UIColorFromRGB(0xF2F2F2)
#define CDCOLOR_BLUE                    UIColorFromRGB(0x63B1D5)            //蓝色
#define CDCOLOR_ORANGE                  UIColorFromRGB(0xF09D3B)            //橙色
#define CDCOLOR_YELLOW                  UIColorFromRGB(0xFFD200)            //黄色
#define CDCOLOR_WORDGERY                UIColorFromRGB(0x989697)
#define CDCOLOR_PINK                    UIColorFromRGB(0xFD4A72)
#define CDCOLOR_WHITE                   UIColorFromRGB(0xFFFFFF)

#define tableviewbackgroundcolor        [UIColor colorWithRed:239/255.0 green:239/255.0 blue:244/255.0 alpha:1.0]

#define CDCOLOR_DANHUI                  [UIColor colorWithRed:225/255.0 green:225/255.0 blue:225/255.0 alpha:1.0]


#define CDBtnGreen_Normal          UIColorFromRGB(0x8ACF1C)            //绿色未点击
#define CDBtnGreen_Highlight       UIColorFromRGB(0x77B218)            //绿色已点击
#define CDBtnGray_Normal           UIColorFromRGB(0x999999)            //灰色未点击
#define CDBtnGray_Highlight        UIColorFromRGB(0x878787)            //灰色已点击

//向日葵淡蓝色
#define COLOR_TEXT                      [UIColor colorWithRed:119/255.0 green:174/255.0 blue:226/255.0 alpha:1.0]
/*  字体
 TF For Text Font
 */
#define FONT(fontsize)                  [UIFont systemFontOfSize:fontsize]

#define FONTNAME                        @"Helvetica Neue"

#define TF11                            11.0f
#define TF12                            12.0f
#define TF13                            13.0f
#define TF19                            19.0f


/*  存储命名
 UD For userdefaults
 */
#define UDFirstLanunch                  @"firstLaunch"          // 首次启动
#define kRememberUserName               @"rememberUserName"     // 记住登录账号


/*  定义
 DF For Define
 */
#define LOADING_TEXT                    @"发送数据"
#define DFSHARE_TITLE                   @"和我一起做一只懒懒的考拉"
#define IMAGE_PLACE                     @"placeImage"
#define IMAGE_BREAK_CUBE                @"picture_break_cube"
#define kNetworkFailedMessage           @"网络未连接"

/*  key
 K For Key
 */

#define KUMENG                      @""



/*  通知
 NT For Notification
 */
#define NTPAY_SUCCESS                                     @"pay_success"
#define RELOAD_APP_DATA                                 @"ReloadApplicationDataNotification"




//主色
#define ZhuSe                           [UIColor colorWithRed:28/255.0 green:162/255.0 blue:232/255.0 alpha:1.0]

//随机色
#define CDCOLOR_RANDOM                  [UIColor colorWithRed:arc4random()%255/255.0 green:arc4random()%255/255.0 blue:arc4random()%255/255.0 alpha:1.0]



#define IMG_ZHUSE       [Utility imageWithColor:ZhuSe andSize:CGSizeMake(1, 1)]






#define IMG_Back(color)     [Utility imageWithColor:color andSize:CGSizeMake(100, 100)]




#endif /* Define_h */
