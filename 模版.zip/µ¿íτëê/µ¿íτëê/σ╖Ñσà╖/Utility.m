//
//  Utility.m
//  每家美护
//
//  Created by 陆晓波 on 15/7/10.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "Utility.h"
#import "DashedView.h"

#import "Masonry.h"
@implementation Utility

//!!!!: 将时间戳转换为指定格式时时间
/**
 *  将时间戳转换为指定格式时时间
 *
 *  @param strTimestamp  传入的时间戳
 *  @param strDateFormat 时间的格式
 *
 *  @return 返回的时间
 */
+ (NSString *)getTimeWithTimestamp:(NSString *)strTimestamp WithDateFormat:(NSString *)strDateFormat
{
    if ([strTimestamp isEqualToString:@"0"]||[strTimestamp length]==0)
    {
        return @"";
    }
    
    
    long long time;
    if (strTimestamp.length == 10) {
        time = [strTimestamp longLongValue];
    }
    else if (strTimestamp.length == 13){
        time = [strTimestamp longLongValue]/1000;
    }
    
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:time];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:strDateFormat];
    NSString *strTime = [formatter stringFromDate:date];
    return strTime;
}

//画顶部线
+ (void)topLine:(UIView *)aView
{
    
    UIView *bottomLine = [[UIView alloc] init];
    [aView addSubview:bottomLine];
    bottomLine.backgroundColor = CDCOLOR_LINE;
    [bottomLine mas_makeConstraints:^(MASConstraintMaker *make)
     {
         make.left.equalTo(aView.mas_left).with.offset(0);
         make.right.equalTo(aView.mas_right).with.offset(0);
         make.top.equalTo(aView.mas_top).with.offset(0);
         make.height.mas_equalTo(@0.5);
     }];
}

//画底部线
+ (void)bottomLine:(UIView *)aView
{
    UIView *bottomLine = [[UIView alloc] init];
    [aView addSubview:bottomLine];
    bottomLine.backgroundColor = CDCOLOR_LINE;
    [bottomLine mas_makeConstraints:^(MASConstraintMaker *make)
    {
        make.left.equalTo(aView.mas_left).with.offset(0);
        make.right.equalTo(aView.mas_right).with.offset(0);
        make.bottom.equalTo(aView.mas_bottom).with.offset(0);
        make.height.mas_equalTo(@0.5);
    }];
}
//画右部线-带颜色
+ (void)rightLine:(UIView *)aView color:(UIColor*)color
{
    UIView *bottomLine = [[UIView alloc] init];
    [aView addSubview:bottomLine];
    bottomLine.backgroundColor = color;
    [bottomLine mas_makeConstraints:^(MASConstraintMaker *make)
     {
         make.top.equalTo(aView.mas_top).with.offset(0);
         make.right.equalTo(aView.mas_right).with.offset(0);
         make.bottom.equalTo(aView.mas_bottom).with.offset(0);
         make.height.mas_equalTo(@0.5);
     }];
}
+ (UIImage *)imageWithColor:(UIColor *)color andSize:(CGSize)size
{
    CGRect rect = CGRectMake(0.0f, 0.0f, size.width, size.height);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}
//画水平直线
+ (void)drawHorizontalLineWithPoint:(CGPoint)point AndLength:(CGFloat)length InView:(UIView *)view{
    [Utility drawHorizontalLineWithFrame:point AndLength:length AndColor:CDLineColor InView:view];
}

+ (void)drawHorizontalLineWithFrame:(CGPoint)point AndLength:(CGFloat)length AndColor:(UIColor *)color InView:(UIView *)view{
    UIView *lineView = [[UIView alloc]initWithFrame:CGRectMake(point.x, point.y, length, 0.5)];
    lineView.backgroundColor = color;
    [view addSubview:lineView];
}
//画垂直直线
+ (void)drawVerticalLineWithFrame:(CGPoint)point AndLength:(CGFloat)length InView:(UIView *)view{
    [Utility drawVerticalLineWithFrame:point AndLength:length AndColor:CDLineColor InView:view];
}
+ (void)drawVerticalLineWithFrame:(CGPoint)point AndLength:(CGFloat)length AndColor:(UIColor *)color InView:(UIView *)view{
    UIView *lineView = [[UIView alloc]initWithFrame:CGRectMake(point.x, point.y, 0.5, length)];
    lineView.backgroundColor = color;
    [view addSubview:lineView];
}

//画水平虚线
+ (void)drawHorizontalDashedWithPoint:(CGPoint)point AndLength:(CGFloat)length InView:(UIView *)view{
    [Utility drawHorizontalDashedWithFrame:point AndLength:length AndColor:CDLineColor InView:view];
}

+ (void)drawHorizontalDashedWithFrame:(CGPoint)point AndLength:(CGFloat)length AndColor:(UIColor*)color InView:(UIView *)view{
    DashedView *dashedView = [[DashedView alloc]initWithFrame:CGRectMake(point.x, point.y,length,0.5) AndColor:color];
    [dashedView setNeedsDisplay];
    [view addSubview:dashedView];
    
}



+ (void)setRightArrow:(UITableViewCell*)cell{
    UIImageView *rightArrowImgView = [[UIImageView alloc] init];
    [cell.contentView addSubview:rightArrowImgView];
    rightArrowImgView.image = [UIImage imageNamed:@"arrow_1"];
    [rightArrowImgView mas_makeConstraints:^(MASConstraintMaker *make)
     {
         make.right.equalTo(cell.contentView.mas_right).with.offset(- 12);
         make.centerY.equalTo(cell.contentView.mas_centerY);
         make.size.mas_equalTo(CGSizeMake(13 / 2, 24 / 2 ));
     }];
}

//!!!!: 单纯文字导航按钮
+ (UIBarButtonItem *)navButton:(id)_target title:(NSString*)title action:(SEL)selector
{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(270, 0, 60, 44);
    [btn setTitle:title forState:UIControlStateNormal];
//    btn.titleLabel.font = [UIFont fontWithName:FONTNAME size:15.0f];
    btn.titleLabel.font = [UIFont systemFontOfSize:15];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
//    [btn setTitleColor:CDBtnGreen_Highlight forState:UIControlStateHighlighted];
    
    //    [btn setTitleColor:[UIColor colorWithRed:30.0 / 255.0 green:120.0 / 255.0 blue:60.0 / 255.0 alpha:1] forState:UIControlStateHighlighted];
    btn.titleEdgeInsets = UIEdgeInsetsMake(0, 0, 0, - 30);
    [btn addTarget:_target action:selector forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithCustomView:btn];
    return item;
}

/**
 *	@brief	指定字符串中 改变指定字符字体及颜色
 *
 *	@param 	fullStr 	    原本字符串
 *	@param 	fullStrFont 	原本字符串的字体
 *	@param 	fullStrColor 	原本字符串的颜色
 *	@param 	changeStrArray 	数组，元素是需要改变字体及颜色的字符
 *	@param 	changeStrFont 	需要改变的字体
 *	@param 	changeStrColor 	需要改变的颜色
 *
 *	@return	NSMutableAttributedString
 */
+(NSMutableAttributedString *)setFullStr:(NSString *)fullStr fullStrWithFont:(UIFont *)fullStrFont fullStrWithColor:(UIColor *)fullStrColor needChangeStrArray:(NSArray *)changeStrArray changeStrWithFont:(UIFont *)changeStrFont changeStrColor:(UIColor *)changeStrColor

{
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc]initWithString:fullStr];
    [str addAttribute:NSForegroundColorAttributeName value:fullStrColor range:NSMakeRange(0, fullStr.length)];
    [str addAttribute:NSFontAttributeName value:fullStrFont range:NSMakeRange(0, fullStr.length)];
    
    for (int i = 0; i < fullStr.length; i++)
    {
        NSString *temp = [fullStr substringWithRange:NSMakeRange(i, 1)];
        if ([changeStrArray containsObject:temp] == YES)
        {
            [str addAttribute:NSForegroundColorAttributeName value:changeStrColor range:NSMakeRange(i, 1)];
            [str addAttribute:NSFontAttributeName value:changeStrFont range:NSMakeRange(i, 1)];
        }
    }
    return str;
}

+(void)setLoadingHubWithString:(NSString *)str{
    [SVProgressHUD showWithStatus:str maskType:SVProgressHUDMaskTypeBlack];

}

+(void)setLoadingtrueWithString:(NSString *)str{
    [SVProgressHUD showSuccessWithStatus:str maskType:SVProgressHUDMaskTypeBlack];
    
}

+(void)setLoadingErrorWithString:(NSString*)str WithTarget:(BaseViewController *)tar{
    tar.loadFlag = YES;
    [SVProgressHUD showErrorWithStatus:str maskType:SVProgressHUDMaskTypeBlack];
}

+ (void) loadingStartTarget:(BaseViewController*)vc{
    vc.loadFlag = NO;
}



+ (void) loadingEndTarget:(BaseViewController*)vc{
    [SVProgressHUD dismiss];
    vc.loadFlag = YES;
}
+ (void)showToastWithMessage:(NSString *)message
{
    [SVProgressHUD showInfoWithStatus:message];
}

+ (UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size

{
    
    @autoreleasepool {
        
        CGRect rect = CGRectMake(0, 0, size.width, size.height);
        
        UIGraphicsBeginImageContext(rect.size);
        
        CGContextRef context = UIGraphicsGetCurrentContext();
        
        CGContextSetFillColorWithColor(context,
                                       
                                       color.CGColor);
        
        CGContextFillRect(context, rect);
        
        UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
        
        UIGraphicsEndImageContext();
        
        
        
        return img;
        
    }
    
    
    
}
// View => img
+ (UIImage*) imageWithUIView:(UIView*) view{
    
    // 创建一个bitmap的context
    // 并把它设置成为当前正在使用的context
    UIGraphicsBeginImageContext(view.bounds.size);
    CGContextRef currnetContext = UIGraphicsGetCurrentContext();
    [view.layer renderInContext:currnetContext];
    // 从当前context中创建一个改变大小后的图片
    UIImage* image = UIGraphicsGetImageFromCurrentImageContext();
    // 使当前的context出堆栈
    UIGraphicsEndImageContext();
    return image;
}



//+ (BOOL)isNumText:(NSString *)str{
//    NSString * regex        = @"(/^[0-9]*$/)";
//    NSPredicate * pred      = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
//    BOOL isMatch            = [pred evaluateWithObject:str];
//    
//    if (isMatch) {
//        return YES;
//    }else{
//        return NO;
//    }
//}
//判断字符串中除数字外是否有字母或特殊符号
+ (BOOL)isPureNumandCharacters:(NSString *)string
{
    string = [string stringByTrimmingCharactersInSet:[NSCharacterSet decimalDigitCharacterSet]];
    
    if(string.length > 0)
    {
        
        return NO;
        
    }
    return YES;
    
}

//手机号正则表达式
+ (BOOL)isMobileNumber:(NSString *)mobileNum
{
    /**
     * 手机号码
     * 移动：134[0-8],135,136,137,138,139,150,151,157,158,159,182,187,188
     * 联通：130,131,132,152,155,156,185,186
     * 电信：133,1349,153,180,189
     */
    NSString * MOBILE = @"^1(3[0-9]|5[0-35-9]|8[025-9])\\d{8}$";
    /**
     10         * 中国移动：China Mobile
     11         * 134[0-8],135,136,137,138,139,150,151,157,158,159,182,187,188
     12         */
    NSString * CM = @"^1(34[0-8]|(3[5-9]|5[017-9]|8[2378])\\d)\\d{7}$";
    /**
     15         * 中国联通：China Unicom
     16         * 130,131,132,152,155,156,185,186
     17         */
    NSString * CU = @"^1(3[0-2]|5[256]|8[56])\\d{8}$";
    /**
     20         * 中国电信：China Telecom
     21         * 133,1349,153,180,189
     22         */
    NSString * CT = @"^1((33|53|8[09])[0-9]|349)\\d{7}$";
    /**
     25         * 大陆地区固话及小灵通
     26         * 区号：010,020,021,022,023,024,025,027,028,029
     27         * 号码：七位或八位
     28         */
    // NSString * PHS = @"^0(10|2[0-5789]|\\d{3})\\d{7,8}$";
    
    NSPredicate *regextestmobile = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", MOBILE];
    NSPredicate *regextestcm = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", CM];
    NSPredicate *regextestcu = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", CU];
    NSPredicate *regextestct = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", CT];
    
    if (([regextestmobile evaluateWithObject:mobileNum] == YES)
        || ([regextestcm evaluateWithObject:mobileNum] == YES)
        || ([regextestct evaluateWithObject:mobileNum] == YES)
        || ([regextestcu evaluateWithObject:mobileNum] == YES))
    {
        return YES;
    }
    else
    {
        return NO;
    }
}
//转换时间戳
+ (NSString *)conversionDateToStringYYYYMMddByDate:(NSDate *)date {
    NSDateFormatter* fmt = [[NSDateFormatter alloc] init];
    fmt.locale = [[NSLocale alloc] initWithLocaleIdentifier:@"zh_CN"];
    fmt.dateFormat = @"yyyy-MM-dd";
    NSString* dateString = [fmt stringFromDate:date];
    
    return dateString;
}
//判断字符串是否为空
+(NSString*)nullZhuan:(NSString*)con with:(NSString*)state
{
    if ([con isKindOfClass:[NSNull class]]) {
        return state;
    }else{
        return [NSString stringWithFormat:@"%@",con];
    }
    
}
//计算文本高度的Rect
+(CGRect)rectWithText:(NSString*)string withWidth:(CGFloat)width withFont:(int)font
{
    
    //    CGSize textsize=CGSizeMake(kScreenWidth-40*kScBibi, 0);
    
    NSDictionary *attribute=@{NSFontAttributeName:FONT(font)};
    
    CGRect labelsize=[string boundingRectWithSize:CGSizeMake(width, 0)
                      
                                          options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading
                      
                                       attributes:attribute
                      
                                          context:nil];
    
    return labelsize;
}



@end
