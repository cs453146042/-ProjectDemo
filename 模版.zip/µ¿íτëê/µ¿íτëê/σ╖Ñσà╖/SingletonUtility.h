//
//  SingletonUtility.h
//  天天向日葵
//
//  Created by 崔峰 on 15/12/1.
//  Copyright © 2015年 上海 稼禾建设. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SingletonUtility : NSObject


- (void)resetCDBtn:(UIButton*)btn;

- (void)loadCDBtn:(UIButton*)btn;

+ (SingletonUtility*)utility;


@end
