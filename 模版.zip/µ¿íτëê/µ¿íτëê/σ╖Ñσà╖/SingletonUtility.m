//
//  SingletonUtility.m
//  天天向日葵
//
//  Created by 崔峰 on 15/12/1.
//  Copyright © 2015年 上海 稼禾建设. All rights reserved.
//

#import "SingletonUtility.h"

#define kRegisterTime      120

@implementation SingletonUtility


+ (SingletonUtility*)utility{
    static  SingletonUtility  *su = nil;
    if (su == nil){
        su = [[SingletonUtility alloc]init];
    }
    return su;
}

- (void)resetCDBtn:(UIButton*)btn{
    NSDate * currentTime = [NSDate date];
    [[NSUserDefaults standardUserDefaults]setObject:currentTime forKey:@"lastTime"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    [self setCDBtn:btn AndTime:kRegisterTime];
}

- (void)loadCDBtn:(UIButton*)btn{
    NSDate * currentTime = [NSDate date];
    NSDate * lastTime = [[NSUserDefaults standardUserDefaults]objectForKey:@"lastTime"];
    if (lastTime == nil)
        return;
    NSTimeInterval time = [currentTime timeIntervalSinceDate:lastTime];
    NSLog(@"%@\n%@",currentTime,lastTime);
    NSLog(@"%f",time);
    if (time>kRegisterTime) return;
    [self setCDBtn:btn AndTime:kRegisterTime - time];
}

- (void)setCDBtn:(UIButton*)btn AndTime:(NSInteger)index{
    if (index>0)
    {
        [btn setTitle:[NSString stringWithFormat:@"%ld秒再次获取",index] forState:UIControlStateNormal];
        btn.userInteractionEnabled = NO;
        [self performSelector:@selector(tmpSelector:) withObject:@[btn,[NSNumber numberWithInteger:index]] afterDelay:1];
    }else{
        [btn setTitle:@"点击获取验证码" forState:UIControlStateNormal];
        btn.userInteractionEnabled = YES;
    }
}

- (void)tmpSelector:(NSArray*)arr{
    [self setCDBtn:arr[0] AndTime:[arr[1] integerValue] - 1];
}

@end
