//
//  BaseViewController.h
//  天天向日葵
//
//  Created by 崔峰 on 15/12/1.
//  Copyright © 2015年 上海 稼禾建设. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SVProgressHUD.h"

@interface BaseViewController : UIViewController

@property (nonatomic,strong)UIButton *bottomBtn;
@property (nonatomic,copy) NSMutableArray *baseArray;
@property (nonatomic,assign)BOOL loadFlag;

@property (nonatomic,strong) UIView* navigationView;
@property (nonatomic, strong) UIView* alphaView;
@property (nonatomic,strong) UILabel* titleBaseLab;
@property (nonatomic,strong) UIButton * right_64_TopViewBtn;

- (void)setBottomBtn;

-(NSString*)panduanStr:(id)str1;

-(NSInteger)create_tokenFiled:(id )data;
//- (void)loadBaseTableView;

-(NSString*)Add_URL:(NSString*)str;

-(UIButton*)creatLeftBack_base;
-(void)creat_64_TopView:(int)IsLeft;

-(void)jiazai;

-(void) maketabbarclear;

-(void) maketabbarshow;

-(void) makenavgationclear;

-(void) makenavgationshow;

-(void)hideleftuibuttom;
@end
