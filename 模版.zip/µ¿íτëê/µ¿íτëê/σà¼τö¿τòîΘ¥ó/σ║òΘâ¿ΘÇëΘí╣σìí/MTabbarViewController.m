//
//  MTabbarViewController.m
//  模版
//
//  Created by 程帅 on 15/12/31.
//  Copyright © 2015年 程帅. All rights reserved.
//

#import "MTabbarViewController.h"
#import "TabbarButton.h"
#import "GeRenZhongXinViewController.h"
#import "LogViewController.h"
#import "AppDelegate.h"
@interface MTabbarViewController ()<UITabBarControllerDelegate>

@end

@implementation MTabbarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self tabbarBackgourndView];
    
    [self createTabbars];
    
    [self configViewControllers];
    
    
    self.delegate = self;
    // Do any additional setup after loading the view.
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark 设置tabbar的底部view
-(void)tabbarBackgourndView
{
    _tabbarView = [[UIImageView alloc] initWithFrame:self.tabBar.bounds];
    _tabbarView.backgroundColor = [UIColor whiteColor];
//    _tabbarView.backgroundColor = CDCOLOR_GREEN;
    [self.tabBar addSubview:_tabbarView];
    _tabbarView.userInteractionEnabled = YES;
}
-(void)createTabbars
{
    NSArray *imgArray = @[@"1"
                          ,@"2"
                          ];
    NSArray *selectedImageArr = @[@"1"
                                  ,@"2"
                                  ];
    NSArray *titleArray = @[@"首页",@"我"];
    NSLog(@"%ld",imgArray.count);
    for (int i = 0; i<imgArray.count; i++) {
        
        TabbarButton *btn = [TabbarButton buttonWithType:UIButtonTypeCustom];
        
        [btn setImage:[UIImage imageNamed:imgArray[i]] forState:UIControlStateNormal];
        
        [btn setImage:[UIImage imageNamed:selectedImageArr[i]] forState:UIControlStateSelected];
        
        [btn setTitle:titleArray[i] forState:UIControlStateNormal];
        
        [btn setTitleColor:CDCOLOR_SMOKE forState:UIControlStateNormal];
        
        [btn setTitleColor:CDCOLOR_BLUE forState:UIControlStateSelected];
        
        btn.frame = CGRectMake(i*kScreenWidth/2.0, 0, kScreenWidth/2.0, 64);
        
        btn.tag = 100 + i;
        
        [_tabbarView addSubview:btn];
        
        [btn addTarget:self action:@selector(clickAction:) forControlEvents:UIControlEventTouchUpInside];
        
        if (i == 0) {
            btn.selected = YES;
        }
    }
}
-(void)clickAction:(TabbarButton *)btn
{
    for (UIView *view in _tabbarView.subviews) {
        //判断view,是否是uibutton的对象,或者其子类的对象
        if ([view isKindOfClass:[UIButton class]]) {
            UIButton *b = (UIButton *)view;
            b.selected = NO;
        }
    }
    btn.selected = YES;
    NSInteger index = btn.tag - 100;
    self.selectedIndex = index;
}
- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController
{
    NSInteger index = [self.viewControllers indexOfObject:viewController];
    for (UIView *view in _tabbarView.subviews) {
        //判断view,是否是uibutton的对象,或者其子类的对象
        if ([view isKindOfClass:[UIButton class]]) {
            UIButton *b = (UIButton *)view;
            b.selected = NO;
            if (b.tag == 100 + index) {
                b.selected = YES;
            }
        }
    }
}

-(BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController{
    NSInteger index = [self.viewControllers indexOfObject:viewController];
//    if (index == 0 || index == 3) {
//        return YES;
//    }
    if(index == 1)
    {
//        GeRenZhongXinViewController *vc = [[GeRenZhongXinViewController alloc] init];
//        UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:vc];
//        AppDelegate *appDele = SHARED_APP_DELEGATE;
//        [appDele.window.rootViewController presentViewController:navigation animated:YES completion:nil];
//        self.navigationItem.leftBarButtonItem = nil;
//        UIButton *backBarButton = [UIButton buttonWithType:UIButtonTypeCustom];
//        backBarButton.frame = CGRectMake(0, 20, 15, 20);
//        [backBarButton setImage:[UIImage imageNamed:@"返回"] forState:UIControlStateNormal];
//        [backBarButton addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
//        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:backBarButton];
////        //---------------------------------------------
//
//        
//        return NO;
        
        if(![UserTool share].HasLogin)
        {
            LogViewController *vc = [[LogViewController alloc] init];
            UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:vc];
            AppDelegate *appDele = SHARED_APP_DELEGATE;
            [appDele.window.rootViewController presentViewController:navigation animated:YES completion:nil];
            return NO;
        }
    }
    
    
    return YES;
}
//-(void)backAction
//{
//    LogViewController *vc = [[LogViewController alloc] init];
//    
//   [self.navigationController presentViewController:vc animated:YES completion:nil];
//}
-(void)configViewControllers
{
    NSMutableArray *vcArr = [[NSMutableArray alloc]init];
    NSArray *arr = @[@"ShouYeViewController"
                     ,@"GeRenZhongXinViewController"
                     ];
    NSArray *titleArr = @[@"首页"
                          ,@"个人中心"
                          ];
    for (int i = 0;i<arr.count;i++) {
        NSString *str = arr[i];
        UIViewController *vc = [[NSClassFromString(str) alloc]init];
        UINavigationController *navi = [[UINavigationController alloc]initWithRootViewController:vc];
        
        vc.navigationItem.title = titleArr[i];
        
        [vcArr addObject:navi];
    }
    self.viewControllers = vcArr;
}
/**< 重新设置tabbar */
- (void)reSetTabBar:(NSInteger)index
{
    for (UIView *view in _tabbarView.subviews) {
        //判断view,是否是uibutton的对象,或者其子类的对象
        if ([view isKindOfClass:[UIButton class]]) {
            UIButton *b = (UIButton *)view;
            b.selected = NO;
            if (b.tag == 100 + index) {
                b.selected = YES;
            }
        }
    }
    [self setSelectedIndex:index];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
