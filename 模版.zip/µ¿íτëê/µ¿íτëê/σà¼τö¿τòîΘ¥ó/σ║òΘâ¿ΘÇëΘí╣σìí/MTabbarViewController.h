//
//  MTabbarViewController.h
//  模版
//
//  Created by 程帅 on 15/12/31.
//  Copyright © 2015年 程帅. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MTabbarViewController : UITabBarController

@property (nonatomic,strong) UIImageView *tabbarView;

- (void)reSetTabBar:(NSInteger)index; /**< 重新设置tabbar */


@end
