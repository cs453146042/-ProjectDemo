//
//  BaseViewController.m
//  天天向日葵
//
//  Created by 崔峰 on 15/12/1.
//  Copyright © 2015年 上海 稼禾建设. All rights reserved.
//

#import "BaseViewController.h"
#import "SVProgressHUD.h"
#import "Utility.h"
#import "Define.h"
@interface BaseViewController ()
{
    NSDictionary *dataDic;
}

@end

@implementation BaseViewController

- (void)viewDidAppear:(BOOL)animated{
    [self performSelector:@selector(changeFlag) withObject:nil afterDelay:0.5];
}
- (void)viewWillDisappear:(BOOL)animated{
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
}
#pragma mark 正在加载
-(void)jiazai
{
    [self performSelector:@selector(changeFlag) withObject:nil afterDelay:0.5];
    
}
- (void)changeFlag{
    if (!_loadFlag)
        [Utility setLoadingHubWithString:@"正在载入中....."];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    _loadFlag = YES;
    _baseArray = [[NSMutableArray alloc] init];
    self.view.backgroundColor = [UIColor colorWithRed:245.0/255 green:245.0/255 blue:245.0/255 alpha:1];
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    self.navigationController.navigationBar.barTintColor = ZhuSe;
   
    [self.navigationController.navigationBar setTranslucent:YES];
    self.navigationController.navigationBar.titleTextAttributes = [NSDictionary dictionaryWithObject:[UIColor whiteColor] forKey:NSForegroundColorAttributeName];
//左边返回键
    UIButton *backBarButton = [UIButton buttonWithType:UIButtonTypeCustom];
    backBarButton.frame = CGRectMake(0, 20, 15, 20);
    [backBarButton setImage:[UIImage imageNamed:@"返回"] forState:UIControlStateNormal];
    [backBarButton addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:backBarButton];
//---------------------------------------------
    //隐藏右边、tabBar
//    self.tabBarController.tabBar.hidden = YES;
//    self.navigationItem.rightBarButtonItem = nil;
}

- (void)backAction{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)setBottomBtn{
    UIView *btnView = [[UIView alloc]initWithFrame:CGRectMake(0, self.view.bounds.size.height - 60 -kTabBarHeight, self.view.bounds.size.width, 60)];
    btnView.backgroundColor = [UIColor whiteColor];
    _bottomBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _bottomBtn.frame = CGRectMake(20, 10, self.view.bounds.size.width - 40, 40);
    _bottomBtn.backgroundColor = [UIColor colorWithRed:245.0/255 green:64.0/255 blue:101.0/255 alpha:1];
    [_bottomBtn setTitle:@"确定" forState:UIControlStateNormal];
    [_bottomBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    _bottomBtn.layer.cornerRadius = 5;
    _bottomBtn.layer.masksToBounds = YES;
    [self.view addSubview:btnView];
    [btnView addSubview:_bottomBtn];
    [Utility bottomLine:btnView];
    [Utility topLine:btnView];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark  判断token
-(NSInteger)create_tokenFiled:(id )data
{
    if([data[@"data"][@"info"] isEqualToString:@"token failed"])
    {
//        LogViewController *vc = [[LogViewController alloc] init];
//        vc.tokenInt = 1;
//        [self.navigationController pushViewController:vc animated:YES];
//        return 1;
    }
    return 2;
}
#pragma mark 判断字符串
-(NSString*)panduanStr:(id)str1
{
    if([str1 isKindOfClass:[NSNull class]] || str1 == nil)
    {
        return @"";
    }
    else
    {
        return str1;
    }
    
}
#pragma mark 加url
-(NSString*)Add_URL:(NSString*)str
{
    return [NSString stringWithFormat:@"%@%@",kBaseUrl,str];
}
#pragma mark   导航栏颜色变化
-(void)creat_64_TopView:(int)IsLeft
{
    if (!_navigationView) {
        
        _navigationView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, 64)];
    }
    if (!_alphaView) {
        _alphaView = [[UIView alloc]
                      initWithFrame:CGRectMake(0, 0, kScreenWidth, 64)];
    }
    _alphaView.alpha = 0.0f;
    _alphaView.backgroundColor = ZhuSe;
    [_navigationView addSubview:_alphaView];
    
    _titleBaseLab = [[UILabel alloc]initWithFrame:CGRectMake(0, 20, kScreenWidth, 44)];
    _titleBaseLab.textAlignment = NSTextAlignmentCenter;
    _titleBaseLab.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:17.0];
    _titleBaseLab.textColor = CDCOLOR_WHITE;
    
    [_alphaView addSubview:_titleBaseLab];
    
    if (IsLeft == 1) {
        UIButton* leftBtn = [self creatLeftBack_base];
        [_navigationView addSubview:leftBtn];
        [leftBtn addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
    }
    _right_64_TopViewBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _right_64_TopViewBtn.frame = CGRectMake(kScreenWidth-70, 20, 60, 44);
    
    _right_64_TopViewBtn.imageEdgeInsets = UIEdgeInsetsMake(12, 20, 12, 24);
    [_right_64_TopViewBtn addTarget:self action:@selector(right_64_TopViewBtn_action) forControlEvents:UIControlEventTouchUpInside];
    [_navigationView addSubview:_right_64_TopViewBtn];
    
    [self.view addSubview:_navigationView];
}
-(UIButton*)creatLeftBack_base
{
    UIButton *backBarButton = [UIButton buttonWithType:UIButtonTypeCustom];
    backBarButton.frame = CGRectMake(0, 20, 60, 44);
    
    [backBarButton setImage:[UIImage imageNamed:@"返回"] forState:UIControlStateNormal];
    backBarButton.imageEdgeInsets = UIEdgeInsetsMake(12, 20, 12, 24);
    //    [backBarButton addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
    
    return backBarButton;
}
-(void)right_64_TopViewBtn_action{
    
}
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    float bili = scrollView.contentOffset.y/(300*kScBibi);
    if (bili < 1.0) {
        _alphaView.alpha = bili;
    }else{
        _alphaView.alpha = 1.0f;
    }
}
#pragma mark 隐藏 或显示tabbar
-(void) maketabbarclear
{
    self.tabBarController.tabBar.hidden = YES;
}
-(void) maketabbarshow
{
    self.tabBarController.tabBar.hidden = NO;
    //    self.tabBarController.hidesBottomBarWhenPushed = YES
}
#pragma mark 隐藏或显示navgation
-(void) makenavgationclear
{
    UINavigationBar* nav = self.navigationController.navigationBar;
    for (id obj in nav.subviews) {
        if ([obj isKindOfClass:[UIImageView class]]) {
            UIImageView* a = (UIImageView*)obj;
            a.hidden = YES;
        }
    }
    
}
-(void) makenavgationshow
{
    UINavigationBar* nav = self.navigationController.navigationBar;
    for (id obj in nav.subviews) {
        if ([obj isKindOfClass:[UIImageView class]]) {
            UIImageView* a = (UIImageView*)obj;
            a.hidden = NO;
            //            }
        }
    }
}
#pragma mark 隐藏左上返回键
-(void)hideleftuibuttom
{
    self.navigationItem.leftBarButtonItem = nil;
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
