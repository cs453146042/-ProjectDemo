//
//  UserTool.m
//  模版
//
//  Created by 程帅 on 15/12/31.
//  Copyright © 2015年 程帅. All rights reserved.
//

#import "UserTool.h"

@implementation UserTool

+(UserTool*)share{
    
    static UserTool *user;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!user) {
            user=[[UserTool alloc] init];
        }
    });
    
    return user;
    
}

-(void)initInfo:(NSDictionary *)infoDic
{
    self.HasLogin=YES;
    self.infoDic=[NSMutableDictionary dictionaryWithDictionary:infoDic];
    NSLog(@"登陆者的信息 = %@",infoDic);
    
    
}
-(void)init:(NSDictionary*)dict{
    
    self.HasLogin=YES;
    self.dic=dict;
    NSLog(@"登陆者的信息 = %@",dict);
    
    
}
-(void)initDWAdress:(NSDictionary *)dwAdress
{
    //    self.DWAdressDic = [[NSMutableDictionary alloc]init];
    self.DWAdressDic = [NSMutableDictionary dictionaryWithDictionary:dwAdress];
    NSLog(@"地址 %@",dwAdress);
    
}

-(void)initJpush:(NSString*)jush{
    
    _jpush_id = [[NSString alloc]init];
    _jpush_id = jush;
}

@end
