//
//  ShouYeViewController.m
//  模版
//
//  Created by 程帅 on 16/1/27.
//  Copyright © 2016年 程帅. All rights reserved.
//

#import "ShouYeViewController.h"
#import "FFScrollView.h"
#import "MyButton.h"
#import "DashedView.h"
#import "SYModel.h"
#import "YYModel.h"
@interface ShouYeViewController ()<UIScrollViewDelegate>

@property(strong,nonatomic) UIScrollView *topView;
@property (strong,nonatomic) UIScrollView *centerView;
@property (strong,nonatomic) UIPageControl *pageCroll;
@property (strong,nonatomic) UIView *headView;
@end

@implementation ShouYeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    [self get_topView];
    [self getcenterView];
    [self hideleftuibuttom];
    NSDictionary *jingdianDic = [NSDictionary dictionaryWithObjectsAndKeys:@"5",@"ctype",@"1",@"page",nil];
    [[HttpRequest request] GETRequestWithURL:[self Add_URL:@"/api.php?m=Api&c=index&a=doclist"]AndParameter:jingdianDic complete:^(id data){
        NSLog(@"中医经典：%@",data);
        [Utility loadingEndTarget:self];
        [self create_tokenFiled:data];
        if([data[@"data"][@"info"]isEqualToString:@"Success"]){
            SYModel *modell = [SYModel yy_modelWithJSON:data];
            NSLog(@"model %@",modell.data.msgData.docsList[0]);

        }else{
            [Utility showToastWithMessage:[NSString stringWithFormat:@"%@",data[@"data"][@"info"]]];
        }
    }failed:^{
        [Utility setLoadingErrorWithString:@"数据获取异常！" WithTarget:self];
    }];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)get_topView
{
    _topView = [[UIScrollView alloc] init];
    _topView.backgroundColor = CDCOLOR_WHITE;
    [self.view addSubview:_topView];
    [_topView mas_makeConstraints:^(MASConstraintMaker *make){
        make.left.equalTo(self.view);
        make.top.equalTo(self.view.mas_top).offset(0*kScBibi);
        make.size.mas_equalTo(CGSizeMake(kScreenWidth, 340*kScBibi+100*kScBibi));
    }];
    NSLog(@"_topView.frame.size.height = %f    _topViewfra.me.size.width = %ld",_topView.frame.size.height,(long)_topView.frame.size.width);
    NSArray *array = @[@"dome_1.jpg",@"dome_2.jpg",@"dome_3.jpg"];
    FFScrollView *ffScroll = [[FFScrollView alloc] initPageViewWithFrame:CGRectMake(0, 0, kScreenWidth, 340*kScBibi) views:array];
    [_topView addSubview:ffScroll];
}
-(void)getcenterView
{
    _headView=[[UIView alloc]init];
    [self.view addSubview:_headView];
    [_headView mas_makeConstraints:^(MASConstraintMaker *make){
        make.left.equalTo(self.view);
        make.top.equalTo(_topView.mas_bottom);
        make.size.mas_equalTo(CGSizeMake(kScreenWidth, 300*kScBibi));
    }];
    _centerView = [[UIScrollView alloc] init];
    _centerView.backgroundColor = CDCOLOR_WHITE;
    _centerView.delegate = self;
    _centerView.pagingEnabled = YES;
    _centerView.showsVerticalScrollIndicator = FALSE;
    _centerView.showsHorizontalScrollIndicator = FALSE;
    _centerView.contentSize = CGSizeMake(kScreenWidth*2, 200*kScBibi);
    [_headView addSubview:_centerView];
    [_centerView mas_makeConstraints:^(MASConstraintMaker *make){
        make.left.equalTo(_headView);
        make.top.equalTo(_headView.mas_top);
        make.size.mas_equalTo(CGSizeMake(kScreenWidth, 300*kScBibi));
        
    }];
    NSLog(@"_centerView.frame.size.height = %ld    _centerView.frame.size.width = %ld",(long)_centerView.frame.size.height,(long)_centerView.frame.size.width);
   
    NSArray* textArr = @[@"免费设计",@"智能报价",@"免费监理",@"视频在线",
                         @"免费验房",@"装修攻略",@"葵花宝",@"全名经纪",
                         @"找设计",@"找工长",@"装修图库",@"装修日志",@"官方客服"];
    MyButton *shouyeBtn;
    for (int i = 0; i<textArr.count; i++) {
       
       shouyeBtn = [[MyButton alloc] init];
        if((i > 3 && i < 8) || i == 12 )
        {
            shouyeBtn.frame = CGRectMake(150*kScBibi*(i%8)+40*kScBibi+40*kScBibi, 140*kScBibi*(i/8)+20*kScBibi, 120*kScBibi, 120*kScBibi);
        }
        else
        {
            shouyeBtn.frame = CGRectMake(150*kScBibi*(i%8)+40*kScBibi, 140*kScBibi*(i/8)+20*kScBibi, 120*kScBibi, 120*kScBibi);
        }
        
        [shouyeBtn setTitle:textArr[i] forState:UIControlStateNormal];
        [shouyeBtn setImage:[UIImage imageNamed:[NSString stringWithFormat:@"SYBtn_%d",1+i]] forState:UIControlStateNormal];
        [shouyeBtn setTitleColor:CDCOLOR_TEXT forState:UIControlStateNormal];
        
        [_centerView addSubview:shouyeBtn];
    }
    [self create_pageView:_centerView];
    NSLog(@"shouyeBtn = %ld",(long)shouyeBtn.frame.size.height                                                                                                                                                                                                                                                                                                                                                 );
    NSLog(@"_centerView.frame.size.height = %ld",(long)_centerView.frame.size.height);
}

-(void)create_pageView:(UIScrollView *)scroll
{
    _pageCroll = [[UIPageControl alloc] init];
    [_headView addSubview:_pageCroll];
    [_pageCroll mas_makeConstraints:^(MASConstraintMaker *make){
        make.centerX.equalTo(scroll.mas_centerX);
        make.top.equalTo(scroll.mas_bottom).offset(-20*kScBibi);
        make.size.mas_equalTo(CGSizeMake(kScreenWidth, 10*kScBibi));
        
    }];
    _pageCroll.numberOfPages = 2;
    _pageCroll.currentPageIndicatorTintColor = ZhuSe;
    _pageCroll.pageIndicatorTintColor = CDCOLOR_TEXT;
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView == _centerView) {
        NSLog(@"%f",(long)scrollView.bounds.origin.x+kScreenWidth/3);
        _pageCroll.currentPage=floor((scrollView.bounds.origin.x+kScreenWidth/3)/kScreenWidth);
    }
    NSLog(@"_topView.frame.size.height = %f    _topViewfra.me.size.width = %ld",_topView.frame.size.height,(long)_topView.frame.size.width);
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
