//
//  LogViewController.m
//  模版
//
//  Created by 程帅 on 16/2/22.
//  Copyright © 2016年 程帅. All rights reserved.
//

#import "LogViewController.h"
#import "AppDelegate.h"
#import "UserTool.h"
#import "GeRenZhongXinViewController.h"
#import "SYModel.h"
#define kDengLu                          @"/api.php?m=api&c=public&a=login"
@interface LogViewController ()<UITextFieldDelegate>
{
    UITextField *_usernameTF;
    UITextField *_passwordTF;
    NSInteger _tokenInt;
}
@property (nonatomic)  NSInteger IsPush;
@end

@implementation LogViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = CDCOLOR_BLUE;
    // Do any additional setup after loading the view.
//    _IsPush =2;
//    [self xuanze:1];
    [self toLogin];
    
   
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)toLogin
{
    //    15179165382
    //    15367496826
    NSMutableDictionary *parame = [[NSMutableDictionary alloc] init];
    [parame setObject:@"18270694920" forKey:@"mobile"];
    [parame setObject:@"111111" forKey:@"password"];
    [[HttpRequest request] POSTRequestWithURL:[self Add_URL:kDengLu] AndParameter:parame complete:^(id data){
        NSMutableDictionary *dd=(NSMutableDictionary*)data;
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        [defaults setValue:[dd objectForKey:@"user_token"] forKey:@"token"];
        [defaults setValue:dd forKey:@"user"];
        NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithObjectsAndKeys:@"18270694920",@"username",@"111111",@"password",@"0",@"type", nil];
        //         if(dict[@""])
        [defaults setValue:dict forKey:kRememberUserName];
        [defaults synchronize];
        UserTool *share = [UserTool share];
        share.userAndPassDic = [NSMutableDictionary dictionaryWithDictionary:dd];
        NSLog(@"_usernameTF _passwordTF%@",share.userAndPassDic);
        NSLog(@"%@  %@",dd[@"hxoject"][@"username"],dd[@"hxoject"][@"password"]);

        [self xuanze:1];

        NSLog(@"55555%@",dd);
        [[UserTool share] init:dd];

    } failed:^(NSString *failed){
    
    }];
    
    
}
-(void)xuanze:(int)role
{
    if (_IsPush == 1) {
        [self dismissViewControllerAnimated:YES completion:nil];
        return;
    }
    AppDelegate *appDel = SHARED_APP_DELEGATE;
    [appDel.tabBarVC.navigationController popToRootViewControllerAnimated:YES];
    [appDel.tabBarVC reSetTabBar:1];
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

- (void)backAction{
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
