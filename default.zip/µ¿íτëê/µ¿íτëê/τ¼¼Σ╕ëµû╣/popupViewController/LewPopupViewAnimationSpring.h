//
//  LewPopupViewAnimationSpring.h
//  LewPopupViewController
//
//  Created by deng on 15/3/5.
//  Copyright (c) 2015年 pljhonglu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UIViewController+LewPopupViewController.h"

@interface LewPopupViewAnimationSpring : NSObject<LewPopupAnimation>

@end
