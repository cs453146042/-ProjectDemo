//
//  LewPopupViewAnimationFade.h
//  LewPopupViewController
//
//  Created by pljhonglu on 15/3/4.
//  Copyright (c) 2015年 pljhonglu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UIViewController+LewPopupViewController.h"

@interface LewPopupViewAnimationFade : NSObject<LewPopupAnimation>

@end
