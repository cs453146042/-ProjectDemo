//
//  MyButton.m
//  MyButton
//
//  Created by 程帅 on 16/1/21.
//  Copyright © 2016年 程帅. All rights reserved.
//

#import "MyButton.h"

@implementation MyButton
-(id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
//         图片自适应了imageview的大小
        self.imageView.contentMode = UIViewContentModeScaleAspectFit;
//        self.imageView.contentMode = UIViewContentModeScaleAspectFill;
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        self.titleLabel.font = [UIFont systemFontOfSize:13];
        
    }
    return self;
}
-(CGRect)imageRectForContentRect:(CGRect)contentRect
{
    CGFloat imageX = 0;
    CGFloat imageY = 0;
    CGFloat imageW = contentRect.size.width;
    CGFloat imageH = contentRect.size.height*0.7;
    return CGRectMake(imageX, imageY, imageW, imageH);
}
-(CGRect)titleRectForContentRect:(CGRect)contentRect
{
    return CGRectMake(0, contentRect.size.height*0.75, contentRect.size.width, contentRect.size.height*0.25);
    
}
@end
