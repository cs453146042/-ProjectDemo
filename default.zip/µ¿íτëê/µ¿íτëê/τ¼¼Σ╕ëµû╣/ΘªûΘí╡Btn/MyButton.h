//
//  MyButton.h
//  MyButton
//
//  Created by 程帅 on 16/1/21.
//  Copyright © 2016年 程帅. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyButton : UIButton

@end
