//
//  MHttpRequestConfig.h
//  天天向日葵
//
//  Created by 崔峰 on 15/12/1.
//  Copyright © 2015年 上海 稼禾建设. All rights reserved.
//

#ifndef _____MHttpRequestConfig_h
#define _____MHttpRequestConfig_h

#define kPageCount 15                       //每页请求数据数

#define kBaseUrl                        @"http://wx.tstweiguanjia.com"



#endif
