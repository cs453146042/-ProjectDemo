//
//  HttpRequest.m
//  天天向日葵
//
//  Created by 崔峰 on 15/12/1.
//  Copyright © 2015年 上海 稼禾建设. All rights reserved.
//

#import "HttpRequest.h"
#import "AFNetworking.h"
#import "UIKit+AFNetworking.h"

@implementation HttpRequest
{
    AFHTTPRequestOperationManager *_manager;
}

+ (HttpRequest *)request{
    static HttpRequest *req = nil;
    if (!req) {
        req = [[HttpRequest alloc] init];
    }
    return req;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        _manager = [[AFHTTPRequestOperationManager alloc] init];
        _manager.responseSerializer = [AFJSONResponseSerializer serializer];
        _manager.requestSerializer.timeoutInterval = 10.0f;
    }
    return self;
}

- (BOOL)netWorkIsWorkable:(NSString*)url{
    __block BOOL isWorkable = NO;
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:[NSURL URLWithString:url]];
    NSOperationQueue *operationQueue = manager.operationQueue;
    [manager.reachabilityManager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        switch (status) {
            case AFNetworkReachabilityStatusReachableViaWiFi:
            case AFNetworkReachabilityStatusReachableViaWWAN:
                isWorkable = YES;
                break;
            case AFNetworkReachabilityStatusNotReachable:
                isWorkable = NO;
            default:
                [operationQueue setSuspended:YES];
                break;
        }
    }];
    [manager.reachabilityManager startMonitoring];
    
    return isWorkable;
}

- (void)GETRequestWithURL:(NSString*)url
             AndParameter: (NSDictionary *) parameter
                 complete:(void(^)(id data))completecb
                   failed:(void(^)())failedcb{
    [_manager GET:url parameters:parameter success:^(AFHTTPRequestOperation *operation, id responseObject) {
        completecb(responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (failedcb != nil)
            failedcb();
    }];

}


- (void)POSTRequestWithURL:(NSString*)url
              AndParameter: (NSDictionary *) parameter
                  complete:(void(^)(id data))completecb
                    failed:(void(^)())failedcb{
    [_manager POST:url parameters:parameter success:^(AFHTTPRequestOperation *operation, id responseObject) {
        completecb(responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (failedcb != nil)
            failedcb();
    }];
    
}

- (void)POSTImageWithURL:(NSString *)url
            AndParameter:(NSDictionary *)parameter
                complete:(void (^)(id responseObject))completecb
                  failed:(void (^)(NSString *error))failedcb {
    [_manager POST:url parameters:parameter constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        for (NSString *dictKey in [parameter allKeys])
        {
            if ([dictKey isEqualToString:@"titlepic"])
            {
                NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
                NSString *documentsDirectory = [paths objectAtIndex:0];
                
                NSString *savedImagePath=[documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.jpg",dictKey]];
                NSData *imageData = [parameter objectForKey:dictKey];
                
                [imageData writeToFile:savedImagePath atomically:YES];
                [formData appendPartWithFileData:[parameter objectForKey:dictKey] name:dictKey fileName:savedImagePath mimeType:@"image/jpeg"];
            }
        }
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        completecb(responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        failedcb(kNetworkFailedMessage);
    }];
}
@end
