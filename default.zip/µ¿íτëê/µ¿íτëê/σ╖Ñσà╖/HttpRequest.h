//
//  HttpRequest.h
//  天天向日葵
//
//  Created by 崔峰 on 15/12/1.
//  Copyright © 2015年 上海 稼禾建设. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HttpRequest : NSObject

+ (HttpRequest*) request;

- (BOOL)netWorkIsWorkable:(NSString*)url;

- (void)GETRequestWithURL:(NSString*)url
                AndParameter: (NSDictionary *) parameter
                complete:(void(^)(id data))completecb
                failed:(void(^)())failedcb;


- (void)POSTRequestWithURL:(NSString*)url
                AndParameter: (NSDictionary *) parameter
                complete:(void(^)(id data))completecb
                failed:(void(^)())failedcb;


- (void)POSTImageWithURL:(NSString *)url
       AndParameter:(NSDictionary *)parameter
          complete:(void (^)(id responseObject))completecb
          failed:(void (^)(NSString *error))failedcb;
@end
