//
//  Utility.h
//  每家美护
//
//  Created by 陆晓波 on 15/7/10.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SVProgressHUD.h"
#import "BaseViewController.h"

@interface Utility : NSObject

//将时间戳转换为时间
+ (NSString *)getTimeWithTimestamp:(NSString *)strTimestamp WithDateFormat:(NSString *)strDateFormat;

//顶部线
+ (void)topLine:(UIView *)aView;

//画底部线
+ (void)bottomLine:(UIView *)aView;

//画右部线-带颜色
+ (void)rightLine:(UIView *)aView color:(UIColor*)color;

+ (UIImage *)imageWithColor:(UIColor *)color andSize:(CGSize)size;

//画横线:(默认不带颜色为灰色)
+ (void)drawHorizontalLineWithPoint:(CGPoint)point AndLength:(CGFloat)length InView:(UIView *)view;
+ (void)drawHorizontalLineWithFrame:(CGPoint)point AndLength:(CGFloat)length AndColor:(UIColor*)color InView:(UIView *)view;

+ (void)drawVerticalLineWithFrame:(CGPoint)point AndLength:(CGFloat)length InView:(UIView *)view;
+ (void)drawVerticalLineWithFrame:(CGPoint)point AndLength:(CGFloat)length AndColor:(UIColor*)color InView:(UIView*)view;
//画虚线:(默认不带颜色为灰色)
+ (void)drawHorizontalDashedWithPoint:(CGPoint)point AndLength:(CGFloat)length InView:(UIView *)view;
+ (void)drawHorizontalDashedWithFrame:(CGPoint)point AndLength:(CGFloat)length AndColor:(UIColor*)color InView:(UIView *)view;

+ (void)setRightArrow:(UITableViewCell*)cell;

//!!!!: 单纯文字导航按钮
+ (UIBarButtonItem *)navButton:(id)_target title:(NSString*)title action:(SEL)selector;

//指定字符串中 改变指定字符字体及颜色
+ (NSMutableAttributedString *)setFullStr:(NSString *)fullStr fullStrWithFont:(UIFont *)fullStrFont fullStrWithColor:(UIColor *)fullStrColor needChangeStrArray:(NSArray *)changeStrArray changeStrWithFont:(UIFont *)changeStrFont changeStrColor:(UIColor *)changeStrColor;

//载入界面的loading效果

+ (void)setLoadingHubWithString:(NSString*)str;
//失败时调用的效果
+ (void)setLoadingErrorWithString:(NSString*)str WithTarget:(BaseViewController*)tar;

//设置网络状态差的时候加载效果
+ (void) loadingStartTarget:(BaseViewController*)vc;

+ (void) loadingEndTarget:(BaseViewController*)vc;

+(void)setLoadingtrueWithString:(NSString *)str;

+ (void)showToastWithMessage:(NSString *)message;
//手机号正则表达式
+ (BOOL)isMobileNumber:(NSString *)mobileNum;
// View => img
+ (UIImage*) imageWithUIView:(UIView*) view;

//+ (BOOL)isNumText:(NSString *)str;
//判断字符串中除数字外是否有字母或特殊符号
+ (BOOL)isPureNumandCharacters:(NSString *)string;
//判断是否为空
+(NSString*)nullZhuan:(NSString*)con with:(NSString*)state;


+ (UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size;
+ (NSString *)conversionDateToStringYYYYMMddByDate:(NSDate *)date;
//label的自适应
+(CGRect)rectWithText:(NSString*)string withWidth:(CGFloat)width withFont:(int)font;
//设置验证码倒计时

@end
