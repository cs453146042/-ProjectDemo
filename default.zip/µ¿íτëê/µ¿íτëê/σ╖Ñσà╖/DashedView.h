//
//  DashedView.h
//  Quartz2D绘图
//
//  Created by apple on 15/7/16.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DashedView : UIView

@property (nonatomic,strong) UIColor* dashedColor;

- (instancetype)initWithFrame:(CGRect)frame AndColor:(UIColor*)color;


@end
