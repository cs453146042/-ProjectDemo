//
//  ShouYeViewController.h
//  模版
//
//  Created by 程帅 on 16/1/27.
//  Copyright © 2016年 程帅. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShouYeViewController : BaseViewController

@property (nonatomic,strong) NSString *name;

@end
