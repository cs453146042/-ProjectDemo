//
//  LogViewController.h
//  模版
//
//  Created by 程帅 on 16/2/22.
//  Copyright © 2016年 程帅. All rights reserved.
//

#import "BaseViewController.h"

@interface LogViewController : BaseViewController

@end
