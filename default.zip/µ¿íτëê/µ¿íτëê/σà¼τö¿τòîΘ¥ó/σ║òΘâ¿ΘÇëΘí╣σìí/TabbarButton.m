//
//  TabbarButton.m
//  模版
//
//  Created by 程帅 on 15/12/31.
//  Copyright © 2015年 程帅. All rights reserved.
//

#import "TabbarButton.h"

@implementation TabbarButton

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(id)initWithFrame:(CGRect)frame
{
//    继承uibutton  所以首先要实现uibutton的方法
    self = [super initWithFrame:frame];
    if(self)
    {
        self.titleLabel.font = [UIFont systemFontOfSize:12];
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
    }
    return self;
}
-(CGRect)titleRectForContentRect:(CGRect)contentRect
{
    return CGRectMake(0, 28, contentRect.size.width, 20);
}
-(CGRect)imageRectForContentRect:(CGRect)contentRect
{
    CGFloat w = contentRect.size.width;
    return CGRectMake(w/2.0-12.5, 3, 25, 25);
}
-(void)setHighlighted:(BOOL)highlighted
{
    
}
@end
