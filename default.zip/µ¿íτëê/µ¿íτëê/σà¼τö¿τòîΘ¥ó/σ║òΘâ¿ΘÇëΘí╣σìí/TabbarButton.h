//
//  TabbarButton.h
//  模版
//
//  Created by 程帅 on 15/12/31.
//  Copyright © 2015年 程帅. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TabbarButton : UIButton



@end
