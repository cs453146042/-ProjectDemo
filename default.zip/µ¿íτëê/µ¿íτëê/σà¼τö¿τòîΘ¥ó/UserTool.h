//
//  UserTool.h
//  模版
//
//  Created by 程帅 on 15/12/31.
//  Copyright © 2015年 程帅. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserTool : NSObject

+(UserTool*)share;

-(void)initInfo:(NSDictionary*)infoDic;
-(void)initJpush:(NSString*)jush;
-(void)initDWAdress:(NSDictionary*)dwAdress;


@property (nonatomic)         BOOL HasLogin;
@property (nonatomic, strong) NSMutableDictionary* infoDic;
@property (nonatomic, strong) NSString * jpush_id;
@property (nonatomic, strong) NSMutableDictionary* DWAdressDic;


@end
